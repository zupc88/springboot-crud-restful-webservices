select 2


select * from instance i where instance_name = 'managed2' limit 1

select * from thread t 

   inner join thread t 
   on i.id = t.instance_id 
   
select * from url_check uc 

select * from heap_memory hm 


select * from `instance` i 
inner join thread 
      on i.thread_id =thread.id 
inner join heap_memory hm 
      on hm.id = i.heap_memory_id 
where i.instance_name ='managed1'


# managed1�� �ֱ� 10���� thread ����
select i.instance_name , i.created_at , t2.execute_thread_idle_count , t2.execute_thread_total_count from `instance` i 
inner join thread t2 
      on i.thread_id =t2.id
where i.instance_name ='managed1'
order by i.created_at desc limit 10


#managed1�� �ֱ� 10����  heap momory ����
select i.instance_name , i.created_at , hm.current_percent , hm.current_size from `instance` i 
inner join heap_memory hm 
      on i.heap_memory_id =hm.id 
where i.instance_name = 'managed1'
order by i.created_at desc limit 10


#managed1�� DB Connection ����
select count(distinct dcp.pool_name) from `instance` i 
inner join db_connection_pool dcp on db_connection_pool_id = i.id


#managed1�� DB Connection ����Ʈ
select distinct dcp.pool_name from `instance` i 
inner join db_connection_pool dcp on db_connection_pool_id = i.id


#managed1�� testDS�� ���� DB Pool ����
select dcp.pool_name , i.created_at , dcp.active_count, dcp.idle_count, dcp.max_size from `instance` i 
inner join db_connection_pool dcp on db_connection_pool_id = i.id
where pool_name = 'testDS'
order by i.created_at desc limit 10