package net.javaguides.springboot.entity;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Table(name = "instance")
public class Instance {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Temporal(value = TemporalType.TIMESTAMP)
	@CreationTimestamp
	private Date createdAt;

	@Column(name = "serviceName")
	private String serviceName;

	@Column(name = "State")
	private String State;

	@Column(name = "serverIP")
	private String serverIP;

	@Column(name = "instanceName")
	private String InstanceName;

	@Column(name = "hostName")
	private String hostName;

	@Column(name = "throughput")
	private String throughput;

	@Column(name = "urlCheck")
	private String urlCheck;


	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "heapMemory_id", referencedColumnName = "id")
	private Heap heapMemory;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "thread_id", referencedColumnName = "id")
	private Thread thread;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "dbConnectionPool_id", referencedColumnName = "id")
	private List<DBPool> dbPoolList = new ArrayList<>();

	public Instance() {

	}

	public Instance(String serviceName, String State, String serverIP, String InstanceName, String hostName, String throughput,  String urlCheck) {
		super();
		this.serviceName = serviceName;
		this.State = State;
		this.serverIP = serverIP;
		this.InstanceName = InstanceName;
		this.hostName = hostName;
		this.throughput = throughput;
		this.urlCheck = urlCheck;

	}

	public String getServiceName() {
		return serviceName;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public String getServerIP() {
		return serverIP;
	}

	public void setServerIP(String serverIP) {
		this.serverIP = serverIP;
	}

	public String getInstanceName() {
		return InstanceName;
	}

	public void setInstanceName(String instanceName) {
		InstanceName = instanceName;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getThroughput() {
		return throughput;
	}

	public void setThroughput(String throughput) {
		this.throughput = throughput;
	}

	public Heap getHeapMemory() {
		return heapMemory;
	}

	public void setHeapMemory(Heap heapMemory) {
		this.heapMemory = heapMemory;
	}

	public Thread getThread() {
		return thread;
	}

	public void setThread(Thread thread) {
		this.thread = thread;
	}

	public List<DBPool> getDbPoolList() {
		return dbPoolList;
	}

	public void setDbPoolList(List<DBPool> dbPoolList) {
		this.dbPoolList = dbPoolList;
	}

	public String geturlCheck() {
		return urlCheck;
	}

	public void seturlCheck(String urlCheck) {
		this.urlCheck = urlCheck;
	}
}
