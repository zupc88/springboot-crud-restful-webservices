package net.javaguides.springboot.entity;

import javax.persistence.*;

@Entity
@Table(name = "url_check")
public class UrlCheck {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "url")
	private String url;

	@Column(name = "check_result")
	private String checkResult;

	@OneToOne()
	private Instance Instance;

	public UrlCheck() {
		
	}

	public UrlCheck(String url, String checkResult) {
		this.url = url;
		this.checkResult = checkResult;
	}

	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getCheckResult() {
		return checkResult;
	}

	public void setCheckResult(String checkResult) {
		this.checkResult = checkResult;
	}
}
