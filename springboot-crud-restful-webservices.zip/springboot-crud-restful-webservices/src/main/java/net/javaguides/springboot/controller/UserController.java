package net.javaguides.springboot.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import net.javaguides.springboot.entity.ExecuteThread;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import net.javaguides.springboot.entity.Instance;
import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.repository.UserRepository;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserRepository userRepository;

	// get all users
	@GetMapping
	public List<Instance> getAllUsers() {
		return this.userRepository.findAll();
	}


	// ExecuteThread Idle 정보 출력
	// http://localhost:8080/api/users/myHomepage/managed1/thread
	@GetMapping("/{svcName}/{insName}/thread")
	public List<ExecuteThread> readData (@PathVariable String svcName, @PathVariable String insName) {
		List<String> a = userRepository.getExecuteThread(svcName, insName);
		List<ExecuteThread> listExecuteThread = new ArrayList<>();

		for(int i=0 ; i<a.toArray().length ; i++) {
			String[] strResult = a.get(i).split(",");

			String instanceName=strResult[0];
			String createdAt=strResult[1];
			String executeThreadIdleCount=strResult[2];
			String executeThreadIdleTotalCount=strResult[3];

			ExecuteThread tmpExecuteThread = new ExecuteThread(instanceName, createdAt, executeThreadIdleCount, executeThreadIdleTotalCount);
			listExecuteThread.add(tmpExecuteThread);
		}
		return listExecuteThread;
	}

	// get user by id
	@GetMapping("/{id}")
	public Instance getUserById(@PathVariable (value = "id") long userId) {
		return this.userRepository.findById(userId)
				.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
	}

	// get user by instance
//	@GetMapping("/{instance}")
//	public Instance getUserByInstance(@PathVariable (value = "instance") String Instance) {
//		return this.userRepository.findByInstance(Instance)
//				.orElseThrow(() -> new ResourceNotFoundException("User not found with Instance :" + Instance));
//	}

	// 테스트(향후 삭제 예정)
	@GetMapping("/test")
//	@Query(value = "SELECT 231 from dual", nativeQuery = true)
	public String now() {
		return "sdf";
	}


//	@GetMapping("/instances")
//	@Query("select 1 from dual")
//	public String getParameters(@RequestParam String id, @RequestParam String email){
//		return "아이디는 "+id+" 이메일은 "+email;
//	}

	@GetMapping(value="/instance", produces = "application/json; charset=utf-8")
	public String get(
	@RequestParam(value="instanceName", required = true) String instanceName){
		//return "{\"coffee\":{\"name\":\"americano\"}}" +instanceName;
		System.out.println("get /instance");

		String jpql = "select i from Instance i ";
		EntityManager em = null;
		
		TypedQuery<Instance> query=em.createQuery(jpql, Instance.class);

		System.out.println("query : "+query);
		return "";

	}



	// create user
	@PostMapping
	public Instance createUser(@RequestBody Instance user) {
		return this.userRepository.save(user);
	}
	
	// update user
	@PutMapping("/{id}")
	public Instance updateUser(@RequestBody Instance Instance, @PathVariable ("id") long userId) {
		Instance existingUser = this.userRepository.findById(userId)
			.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
		existingUser.setServerIP(Instance.getServerIP());
		 existingUser.setInstanceName(Instance.getInstanceName());
		 existingUser.setHostName(Instance.getHostName());
		 existingUser.setThroughput(Instance.getThroughput());
		 return this.userRepository.save(existingUser);
	}
	
	// delete user by id
	@DeleteMapping("/{id}")
	public ResponseEntity<Instance> deleteUser(@PathVariable ("id") long userId){
		Instance existingUser = this.userRepository.findById(userId)
					.orElseThrow(() -> new ResourceNotFoundException("User not found with id :" + userId));
		 this.userRepository.delete(existingUser);
		 return ResponseEntity.ok().build();
	}
}
