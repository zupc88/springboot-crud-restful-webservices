package net.javaguides.springboot.entity;

import javax.persistence.*;

@Entity
@Table(name = "thread")
public class Thread {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@Column(name = "executeThreadTotalCount")
	private Integer executeThreadTotalCount;

	@Column(name = "executeThreadIdleCount")
	private Integer executeThreadIdleCount;

	@Column(name = "stuckThreadCount")
	private Integer stuckThreadCount;

	@OneToOne()
	private Instance Instance;

	public Thread() {

	}

	public Thread(Integer executeThreadTotalCount, Integer executeThreadIdleCount, Integer stuckThreadCount) {
		super();
		this.executeThreadTotalCount = executeThreadTotalCount;
		this.executeThreadIdleCount = executeThreadIdleCount;
		this.stuckThreadCount = stuckThreadCount;
	}
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public Integer getexecuteThreadTotalCount() {
		return executeThreadTotalCount;
	}

	public void setexecuteThreadTotalCount(Integer executeThreadTotalCount) {
		this.executeThreadTotalCount = executeThreadTotalCount;
	}

	public Integer getexecuteThreadIdleCount() {
		return executeThreadIdleCount;
	}

	public void setexecuteThreadIdleCount(Integer executeThreadIdleCount) {
		this.executeThreadIdleCount = executeThreadIdleCount;
	}

	public Integer getstuckThreadCount() {
		return stuckThreadCount;
	}

	public void setstuckThreadCount(Integer stuckThreadCount) {
		this.stuckThreadCount = stuckThreadCount;
	}
}
