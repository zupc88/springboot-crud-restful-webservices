package net.javaguides.springboot.entity;

import javax.persistence.*;

@Entity
@Table(name = "ExecuteThread")
public class ExecuteThread {
    public ExecuteThread(String instance_name, String created_at, String execute_thread_idle_count, String execute_thread_total_count) {
        this.instance_name = instance_name;
        this.created_at = created_at;
        this.execute_thread_idle_count = execute_thread_idle_count;
        this.execute_thread_total_count = execute_thread_total_count;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String instance_name;

    @Column(name = "createdAt")
    private String created_at;

    @Column(name = "executeThreadIdleCount")
    private String execute_thread_idle_count;

    @Column(name = "executeThreadTotalCount")
    private String execute_thread_total_count;

    public String getInstance_name() {
        return instance_name;
    }

    public void setInstance_name(String instance_name) {
        this.instance_name = instance_name;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getExecute_thread_idle_count() {
        return execute_thread_idle_count;
    }

    public void setExecute_thread_idle_count(String execute_thread_idle_count) {
        this.execute_thread_idle_count = execute_thread_idle_count;
    }

    public String getExecute_thread_total_count() {
        return execute_thread_total_count;
    }

    public void setExecute_thread_total_count(String execute_thread_total_count) {
        this.execute_thread_total_count = execute_thread_total_count;
    }
}
