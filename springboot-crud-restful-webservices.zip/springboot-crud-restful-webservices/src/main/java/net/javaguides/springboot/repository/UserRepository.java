package net.javaguides.springboot.repository;

import net.javaguides.springboot.entity.ExecuteThread;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import net.javaguides.springboot.entity.Instance;

import java.util.List;


@Repository
public interface
UserRepository extends JpaRepository<Instance, Long>{
    @Query(value = "select i.instance_name , i.created_at , t2.execute_thread_idle_count , t2.execute_thread_total_count from `instance` i " +
            "inner join thread t2 " +
            "      on i.thread_id =t2.id " +
            "where i.service_name = ?1 and i.instance_name = ?2 " +
            "order by i.created_at desc limit 10", nativeQuery = true)
    List<String> getExecuteThread(String svcName, String insName);
}
