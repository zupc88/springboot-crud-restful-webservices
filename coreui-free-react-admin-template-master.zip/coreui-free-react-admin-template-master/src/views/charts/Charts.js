import React, { useState, useEffect, lazy } from 'react';
import axios from 'axios';
import { CCard, CCardBody, CCardGroup, CCardHeader } from '@coreui/react';
import {
  CChartBar,
  CChartLine,
  CChartDoughnut,
  CChartRadar,
  CChartPie,
  CChartPolarArea,
} from '@coreui/react-chartjs';
import { DocsLink } from 'src/reusable';

const Charts = (props) => {
  const { executeIdleThread } = props;
  let idleThreadValue = [];
  let totalThreadValue = [];

  console.log('**** props ****');
  console.log(executeIdleThread);
  console.log([1, 2, 3, 5]);
  console.log('**************');

  const [instance, setInstance] = useState([]);
  const [thread, setThread] = useState([]);
  const [threadShow, setThreadShow] = useState([]);

  const idleThread = () => {
    const url =
      'http://www.monitorwls.com/api/users/myHomepage/managed1/thread';
    axios
      .get(url, {
        headers: {
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,PATCH,OPTIONS',
        },
      })
      .then((Response) => {
        // console.log(Response.data);
        // eslint-disable-next-line max-len
        // console.log('(Response.data[0].execute_thread_idle_count:' + Response.data[2].execute_thread_idle_count);
        idleThreadValue = [];
        totalThreadValue = [];
        Response.data.forEach((threadInfo) => {
          idleThreadValue.push(threadInfo.execute_thread_idle_count);
          totalThreadValue.push(threadInfo.execute_thread_total_count);
        });
      })
      .catch((Error) => {
        console.log(Error);
      });
  };

  useEffect(() => {
    console.log('[effect] setInterval');
    const timerId = setInterval(() => {
      idleThread();
      console.log(idleThreadValue);
      console.log(totalThreadValue);
    }, 3000);

    return () => {
      console.log('[cleaning up] clearInterval');
      clearInterval(timerId);
    };
  });

  const [monResource, setMonResource] = useState({
    thread: [
      {
        label: 'wasInstance1',
        backgroundColor: '#f87979',
        data: [1, 2, 3, 5],
      },
      {
        label: 'wasInstance2',
        backgroundColor: 'blue',
        data: [15, 32, 3, 25],
      },
      {
        label: 'wasInstance3',
        backgroundColor: 'orange',
        data: [1, 2, 3, 25],
      },
      {
        label: 'wasInstance4',
        backgroundColor: 'green',
        data: [1, 2, 3, 25],
      },
    ],
    heap: [
      {
        backgroundColor: ['#41B883', '#E46651', '#00D8FF', '#DD1B16'],
        data: [65, 35, 80],
      },
      {
        backgroundColor: ['#41B883', '#E46651', '#00D8FF', '#DD1B16'],
        data: [15, 15, 80],
      },
      {
        backgroundColor: ['#41B883', '#E46651', '#00D8FF', '#DD1B16'],
        data: [25, 15, 80],
      },
      {
        backgroundColor: ['#41B883', '#E46651', '#00D8FF', '#DD1B16'],
        data: [53, 15, 80],
      },
    ],
    datasource: [
      {
        label: 'wasInstance1_OracleDS',
        backgroundColor: 'rgb(228,102,81,0.9)',
        data: [7, 5, 7, 8, 9, 8, 12],
      },
      {
        label: 'wasInstance1_mssqlDS',
        backgroundColor: 'rgb(0,216,255,0.9)',
        data: [14, 16, 11, 17, 12, 13, 15],
      },
      {
        label: 'wasInstance2_OracleDS',
        backgroundColor: 'rgb(228,102,81,0.9)',
        data: [17, 5, 37, 8, 9, 8, 12],
      },
      {
        label: 'wasInstance2_mssqlDS',
        backgroundColor: 'rgb(0,216,255,0.9)',
        data: [14, 26, 1, 17, 32, 13, 15],
      },
    ],
    timeStamp: ['11:00', '11:01', '11:02', '11:03', '11:04', '11:05', '11:06'],
  });

  return (
    <CCardGroup columns className="cols-3">
      <CCard>
        <CCardHeader>
          Thread
          <DocsLink href="http://www.chartjs.org" />
        </CCardHeader>
        <CCardBody>
          <CChartBar
            datasets={monResource.thread}
            labels={monResource.timeStamp}
            options={{
              tooltips: {
                enabled: true,
              },
            }}
          />
        </CCardBody>
      </CCard>

      <CCard>
        <CCardHeader>Heap Memory</CCardHeader>
        <CCardBody>
          <CChartDoughnut
            datasets={monResource.heap}
            labels={['Perm', 'Young', 'Old']}
            options={{
              tooltips: {
                enabled: true,
              },
            }}
          />
        </CCardBody>
      </CCard>

      <CCard>
        <CCardHeader>DB Connection Pool</CCardHeader>
        <CCardBody>
          <CChartLine
            datasets={monResource.datasource}
            options={{
              tooltips: {
                enabled: true,
              },
            }}
            labels={monResource.timeStamp}
          />
        </CCardBody>
      </CCard>
    </CCardGroup>
  );
};

export default Charts;
